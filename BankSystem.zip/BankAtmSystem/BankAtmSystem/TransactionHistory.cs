﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAtmSystem
{
    class TransactionHistory
    {
        public string TransactionUserAccount { get; set; }
        public float Transaction_debitrekod { get; set; }
        public float Transaction_creditrekod { get; set; }
        public string TransactionType { get; set; }
        public DateTime TransactionTime { get; set; }
    }
}
