﻿using ConsoleTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAtmSystem
{
    class User
    {
        public string card_no { get; set; }
        public string pin_no { get; set; }
        public string name { get; set; }
        public float balance { get; set; }
        public string acc_no { get; set; }
        public bool cek { get; set; }
        public float withdraw_limit { get; set; }
        public int Login_Attempt { get; set; }

        public User()
        {
            Login_Attempt = 3;
            balance = 10000;
            withdraw_limit = 9980;
        }

        public void table(List<TransactionHistory> q)
        {
            Console.WriteLine($"Hi, {name}");
            Console.WriteLine($"Current Balance is : {balance}");
            var table = new ConsoleTable("No", "Transaction Date", "Account", "Transaction Type", " Debit", " Credit");
            int no = 1;
            foreach (var item in q)
            {
                if (item.TransactionUserAccount == acc_no)
                {
                    table.AddRow(no, item.TransactionTime, item.TransactionUserAccount, item.TransactionType, item.Transaction_debitrekod, item.Transaction_creditrekod);
                    no++;
                }
            }
            table.Options.EnableCount = false;
            table.Write();
            other_method.PrintforUser();
        }
        public void cek_Balance()
        {
            other_method.yellow_head("                    Balance Inquiry ", ConsoleColor.Yellow);
            Console.WriteLine($"\nHi, {name}");
            Console.WriteLine("Current Balance is RM " + balance);
            other_method.PrintforUser();
        }
        public void Login_Successful()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("<-Login Successful->");
            Login_Attempt = 3;
        }
        public void Menu()
        {
            other_method.yellow_head("       Welcome to GE LEGACY BANK ATM SERVICE ", ConsoleColor.Yellow);
            Console.WriteLine($"Hi, {name}");
            Console.WriteLine("1. Balance Inquiry");
            Console.WriteLine("2. Withdrawal ");
            Console.WriteLine("3. Fast Cash Withdrawal ");
            Console.WriteLine("4. Deposit ");
            Console.WriteLine("5. Change Pin ");
            Console.WriteLine("6. Third Party Transfer ");
            Console.WriteLine("7. Transaction History ");
            Console.WriteLine("8. Logout ");
            Console.WriteLine("9. Exit ");
            Console.Write("Enter Your Option:");
        }

        public void Insufficient_Balance()
        {
            Console.WriteLine($"\nYour available balance is RM {balance}.");
            other_method.color_text("Sorry! Insufficient Balance.", ConsoleColor.Red);
        }
        public void Require_Balance(string text, float f)
        {
            Console.WriteLine($"\nCan't {text}  {f} , your available balance is RM {balance}.");
            other_method.color_text("Minimum required balance is RM20. ", ConsoleColor.Red);
        }

        public void Enter_New_Pin()
        {
            Console.Clear();
            Console.WriteLine("Enter Your New Pin No: ");
            string newpin = Console.ReadLine();
            cek = int.TryParse(newpin, out int new_pin);

            if (cek == false)
            {
                other_method.color_text("\nEnter Numbers Only.", ConsoleColor.Blue);
            }
            else if (new_pin < 0)
            {
                other_method.color_text("\nCan't insert negative number. ", ConsoleColor.Red);
            }
            else if (newpin == pin_no)
            {
                other_method.color_text("\nCan't change to the old pin no.  ", ConsoleColor.Red);
            }
            else
            {
                if (newpin == "1")
                {
                    other_method.color_text("\nPin No can't be 1 digit", ConsoleColor.Red);
                }
                else
                {
                    pin_no = newpin;
                    other_method.color_text("\nPin No change successful", ConsoleColor.Green);
                }
            }
        }
        public void Balance_After_Withdraw(float withdraw, List<TransactionHistory> q)
        {
            balance = Calculate.Minus_Balance(this, withdraw); withdraw_limit = Calculate.Minus_WithdrawLimit(this, withdraw);
            q.Add(new TransactionHistory { TransactionUserAccount = acc_no, Transaction_debitrekod = withdraw, Transaction_creditrekod = 0, TransactionTime = DateTime.Now, TransactionType = "WithDraw" });
            other_method.AfterProcess_withdraw();
            Console.WriteLine("After withdraw, current Balance is RM " + balance);
            other_method.yes_no("\nDo you need any receipt?");
        }
        public void Balance_After_FastWithdraw(float withdraw, List<TransactionHistory> q, string s)
        {
            balance = Calculate.Minus_Balance(this, withdraw); withdraw_limit = Calculate.Minus_WithdrawLimit(this, withdraw);
            q.Add(new TransactionHistory { TransactionUserAccount = acc_no, Transaction_debitrekod = withdraw, Transaction_creditrekod = 0, TransactionTime = DateTime.Now, TransactionType = s });
            other_method.AfterProcess_fastwithdraw();
            Console.WriteLine($"After withdraw {withdraw}, current Balance is RM{ balance}");
            other_method.yes_no("\nDo you need any receipt?");
        }
        public void Balance_After_Deposit(float deposit, List<TransactionHistory> q)
        {
            balance = Calculate.Plus_Balance(this, deposit); withdraw_limit = Calculate.Plus_WithdrawLimit(this, deposit);
            q.Add(new TransactionHistory { TransactionUserAccount = acc_no, Transaction_debitrekod = 0, Transaction_creditrekod = deposit, TransactionTime = DateTime.Now, TransactionType = "Deposit" });
            other_method.AfterProcess();
            Console.WriteLine("Current Balance is RM " + balance);
            other_method.yes_no("\nDo you need any receipt?");
        }
        public void Balance_After_Transfer(User r, float transfer, List<TransactionHistory> q)
        {
            balance = Calculate.Minus_Balance(this, transfer); withdraw_limit = Calculate.Minus_WithdrawLimit(this, transfer);
            r.balance = Calculate.Plus_Balance(r, transfer); r.withdraw_limit = Calculate.Plus_WithdrawLimit(r, transfer);
            q.Add(new TransactionHistory { TransactionUserAccount = acc_no, Transaction_debitrekod = transfer, Transaction_creditrekod = 0, TransactionType = "Transfer to " + r.acc_no, TransactionTime = DateTime.Now });
            q.Add(new TransactionHistory { TransactionUserAccount = r.acc_no, Transaction_debitrekod = 0, Transaction_creditrekod = transfer, TransactionType = "Receive from " + acc_no, TransactionTime = DateTime.Now });
            other_method.AfterProcess();
            Console.WriteLine("Current Balance is RM " + balance);
            other_method.yes_no("\nDo you need any receipt?");
        }
        public void fastwithdraw(float num, List<TransactionHistory> q)
        {
            if (num > balance)
            {
                Insufficient_Balance();
            }
            else
            {
                if (num > withdraw_limit)
                {
                    Require_Balance("withdraw", num);
                }
                else
                {
                    Balance_After_FastWithdraw(num, q, "Fast Withdrawal");

                    if (Console.ReadLine() == "1")
                    {
                        other_method.Print_Receipt();
                    }
                    else
                    {
                        Console.Clear();
                    }
                }
            }
        }
    }
}
